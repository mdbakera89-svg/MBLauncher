package com.mb.launcher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

data class McVersion(val id: String, val type: String, val url: String)

object VersionRepository {
    private const val MANIFEST =
        "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"

    suspend fun fetch(): List<McVersion> = withContext(Dispatchers.IO) {
        val arr = JSONObject(URL(MANIFEST).readText()).getJSONArray("versions")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            McVersion(o.getString("id"), o.getString("type"), o.getString("url"))
        }
    }
}
