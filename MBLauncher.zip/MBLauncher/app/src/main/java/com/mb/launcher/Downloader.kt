package com.mb.launcher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.security.MessageDigest

object Downloader {
    private fun sha1(f: File): String {
        val md = MessageDigest.getInstance("SHA-1")
        f.inputStream().use { s ->
            val buf = ByteArray(8192)
            while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    suspend fun file(url: String, dest: File, sha: String? = null) =
        withContext(Dispatchers.IO) {
            if (dest.exists() && (sha == null || sha1(dest) == sha)) return@withContext
            dest.parentFile?.mkdirs()
            URL(url).openStream().use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        }

    /** Downloads the version JSON, client jar and libraries into gameDir. */
    suspend fun version(v: McVersion, gameDir: File, onProgress: (String) -> Unit) {
        val vDir = File(gameDir, "versions/${v.id}")
        val jsonFile = File(vDir, "${v.id}.json")
        file(v.url, jsonFile)
        val json = JSONObject(jsonFile.readText())

        val client = json.getJSONObject("downloads").getJSONObject("client")
        onProgress("Client jar")
        file(client.getString("url"), File(vDir, "${v.id}.jar"), client.getString("sha1"))

        val libs = json.getJSONArray("libraries")
        for (i in 0 until libs.length()) {
            val art = libs.getJSONObject(i).optJSONObject("downloads")
                ?.optJSONObject("artifact") ?: continue
            onProgress("Library ${i + 1}/${libs.length()}")
            file(art.getString("url"), File(gameDir, "libraries/${art.getString("path")}"),
                art.getString("sha1"))
        }
        // TODO: assets (assetIndex -> objects) download goes here
    }
}
