package com.mb.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

val Bg = Color(0xFF0D0D0D)
val Surface2 = Color(0xFF171717)
val Neon = Color(0xFF39FF14)
val TextC = Color(0xFFECECEC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Neon)) { App() } }
    }
}

@Composable
fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var versions by remember { mutableStateOf<List<McVersion>>(emptyList()) }
    var showSnapshots by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<McVersion?>(null) }
    var name by remember { mutableStateOf("Player") }
    var status by remember { mutableStateOf("Ready") }

    LaunchedEffect(Unit) {
        status = try { versions = VersionRepository.fetch(); "Ready" } catch (e: Exception) { "Offline: ${e.message}" }
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp).statusBarsPadding()) {
        Text("MB LAUNCHER", color = Neon, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("Offline username") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = showSnapshots, onCheckedChange = { showSnapshots = it })
            Spacer(Modifier.width(8.dp))
            Text("Show snapshots", color = TextC)
        }

        LazyColumn(Modifier.weight(1f)) {
            items(versions.filter { showSnapshots || it.type == "release" }) { v ->
                val sel = v == selected
                Box(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        .background(if (sel) Neon.copy(alpha = .18f) else Surface2, RoundedCornerShape(12.dp))
                        .clickable { selected = v }.padding(14.dp)
                ) { Text("${v.id}  (${v.type})", color = if (sel) Neon else TextC) }
            }
        }

        Text(status, color = TextC.copy(alpha = .7f), modifier = Modifier.padding(vertical = 6.dp))
        Button(
            enabled = selected != null,
            colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Color.Black),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
            onClick = {
                val v = selected ?: return@Button
                scope.launch {
                    try {
                        Downloader.version(v, ctx.getExternalFilesDir(null)!!) { status = "Downloading: $it" }
                        status = "Downloaded ${v.id}. Runtime bridge needed to start."
                    } catch (e: Exception) { status = "Error: ${e.message}" }
                }
            }
        ) { Text("DOWNLOAD / PLAY", fontWeight = FontWeight.Bold) }
    }
}
