package com.mb.launcher

import java.util.UUID

data class Account(val name: String, val uuid: String, val type: String, val token: String = "0")

object Accounts {
    /** Offline account: same UUID algorithm vanilla uses for offline players. */
    fun offline(name: String) = Account(
        name = name,
        uuid = UUID.nameUUIDFromBytes("OfflinePlayer:$name".toByteArray()).toString(),
        type = "offline"
    )
    // TODO: Microsoft login (device-code flow -> Xbox Live -> XSTS -> Minecraft services)
    // TODO: Ely.by login (POST https://authserver.ely.by/auth/authenticate)
}
