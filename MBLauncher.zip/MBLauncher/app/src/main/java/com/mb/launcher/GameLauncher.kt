package com.mb.launcher

import android.content.Context

/**
 * IMPORTANT: Android has no desktop JVM. To actually start Minecraft Java Edition you need:
 *  1. An Android-built OpenJDK runtime (JRE 8 / 17 / 21) bundled in the APK or downloaded.
 *  2. LWJGL3 + a GL translation layer (e.g. gl4es / ANGLE / Zink) and an input bridge.
 * Open-source projects (PojavLauncher, LGPL-3.0) provide exactly these pieces.
 * Build the command here, then hand it to your runtime bridge.
 */
object GameLauncher {
    fun buildArgs(ctx: Context, v: McVersion, acc: Account, ramMb: Int): List<String> {
        val gameDir = ctx.getExternalFilesDir(null)!!.absolutePath
        return listOf(
            "-Xmx${ramMb}M",
            "-cp", "$gameDir/versions/${v.id}/${v.id}.jar:<libraries...>",
            "net.minecraft.client.main.Main",
            "--username", acc.name, "--uuid", acc.uuid, "--accessToken", acc.token,
            "--version", v.id, "--gameDir", gameDir, "--assetsDir", "$gameDir/assets"
        )
    }
    // TODO: start(runtimeBridge, args)
}
